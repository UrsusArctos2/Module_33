from datetime import datetime
import glob
import json
import dill
import pandas as pd
from pydantic import BaseModel
import os

path = os.environ.get('PROJECT_PATH', '.')
path = os.path.expanduser('~/airflow_hw')


class Form(BaseModel):
    id: int
    url: str
    region: str
    region_url: str
    price: int
    year: float
    manufacturer: str
    model: str
    fuel: str
    odometer: float
    title_status: str
    transmission: str
    image_url: str
    description: str
    state: str
    lat: float
    long: float
    posting_date: str


def predict():
    source = glob.glob(f'{path}/data/models/*')
    latest_file = max(source, key=os.path.getctime)
    with open(latest_file, 'rb') as file:
        model = dill.load(file)

    merge = []
    for filename in glob.glob(f'{path}/data/test/*.json'):
        with open(filename, 'r', encoding='utf-8') as fin:
            form = json.load(fin)
            df = pd.DataFrame.from_dict([form])
            y = model['model'].predict(df)
            x = {'car_id': df.id[0], 'pred': y}
            merge.append(x)
    df_merged = pd.DataFrame.from_dict(merge)
    df_merged.to_csv(f'{path}/data/predictions/predictions_{datetime.now().strftime("%Y%m%d%H%M")}.csv')


if __name__ == '__main__':
    predict()
